<html>
    <body>
        <style>
            .a{
                width:100%;
                height:40px;
                border-bottom:1px solid black;
            }
            .b{
                background-image:url('c.jpeg');
                background-size:100% 100%;
                width:40px;
                height:35px;
                margin-left:10px;
                border-radius:50%;
            }
            .c{
                margin-left:65px;
                margin-top:20px;
                font-weight:bold; background-color:black;
            }
            .menu{
                width:500px;
                height:250px;
            }
            .aa{
                font-weight:bold;
                font-size:30px;
            } 
            .aa1{
                font-weight:bold;
                font-size:30px;
                color:blue;
            }
            .button{
                background-color:DodgerBlue;
            height:30px;
                color:white;
                border :1px solid white;
                border-radius:6px;
            }
            .button1{
                background-color:green;
            height:30px;
                color:white;
                border :1px solid white;
                border-radius:6px;
            }
            input{
            height:30px;
        }
a{ text-decoration:none; color:white;}
.card {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.5);
  transition: 0.3s;
  width: 100%;
  height:150px;
}

.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
}

.container {
  padding: 2px 16px;}
  .f{ width:1500px;
height:300px;  margin-left:100px;
}
.ff{box-shadow: 0 8px 16px 0 rgba(0,0,0,0.5);
  transition: 0.3s; float:left; margin-bottom:50px;
   width:20%; margin-left:100px; height:100%;}
   


        </style>
    </body>
    <form action=# method=post>
    <div class="a">
        <div class=b> <a href=home.php class=c>Home</a><a href=menu.php class=c>Recipes</a></div>
        </div>
       <center> <div class=menu>
        <p class=aa> Search Recipes with<span class=aa1> Our Recipes</span></p>
        Input recipes Separated by Comma(,)<br><br>
        <input type=text name=t1 placeholder=pizza,rice,chiken,dessert,etc><button class=buton>Search</button><br>
     
       </div></center>
 
</div>
    </form>
</html>

<?php
if(isset($_POST['t1']))
{
    echo"<div class=f>";
   
    $a=$_POST['t1'];
    $con=mysqli_connect('localhost','root','','restaurant');
    $q="select * from product where category='$a'";
    $rs=mysqli_query($con,$q);
    while($row=mysqli_fetch_array($rs))
    {
        echo"
        <div class=ff>
        <div class='card'>
  <img src='$row[photo]' alt='photo' style='width:100%; height:100%;'>
  <div class='container'>
    <h4><b>$row[pname]</b></h4> 
    <p>$row[description]</p> <hr>
<button class=button><a href='pizza details.php?id=$row[pname]'>Detail</a></button>
<button class=button1><a href='pizza details.php?id=$row[pname]'>Recipe URL</a></button>
</div>
</div>
  </div>"
  
  ;
    }
    echo"</div><br><div class=dd></div>";
}
?>
<?php
if(isset($_POST['t1']))
{
    echo"<div class=f>";
   
    $a=$_POST['t1'];
    $con=mysqli_connect('localhost','root','','restaurant');
    $q="select * from product where category='$a'";
    $rs=mysqli_query($con,$q);
    while($row=mysqli_fetch_array($rs))
    {
        echo"
        <div class=ff>
        <div class='card'>
  <img src='$row[photo]' alt='photo' style='width:100%; height:100%;'>
  <div class='container'>
    <h4><b>$row[pname]</b></h4> 
    <p>$row[description]</p> <hr>
<button class=button><a href='pizza details.php?id=$row[pname]'>Detail</a></button>
<button class=button1><a href='pizza details.php?id=$row[pname]'>Recipe URL</a></button>
</div>
</div>
  </div>"
  
  ;
    }
    echo"</div><br><div class=dd>1</div>";
}
?>