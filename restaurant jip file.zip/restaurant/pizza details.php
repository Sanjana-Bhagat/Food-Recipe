<!DOCTYPE html>
<html >
  
</head>
<style>
    .flex{display:flex;}
    .detail{
        margin-left:150px;
        margin-top:10px;

    }
    .a{
                width:100%;
                height:40px;
                border-bottom:1px solid black;
            }
            .b{
                background-image:url('c.jpeg');
                background-size:100% 100%;
                width:40px;
                height:35px;
                margin-left:10px;
                border-radius:50%;
               background-color:black;
            }
            .c{
                margin-left:65px;
                margin-top:20px;
                font-weight:bold;
            
            }
            .menu{
                width:500px;
                height:250px;
            }
            .aa{
                font-weight:bold;
                font-size:30px;
            } 
            .aa1{
                font-weight:bold;
                font-size:30px;
                color:blue;
            }
            .button{
                background-color:DodgerBlue;
            height:30px;
                color:white;
                border :1px solid white;
                border-radius:6px;
            }
            .button1{
                background-color:green;
            height:30px;
                color:white;
                border :1px solid white;
                border-radius:6px;
            }
            input{
            height:30px;
        }
        .card {
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition: 0.3s;
  width: 15%;
  height: 15%;
  margin:20px;
}

.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
}

.container {
  padding: 2px 16px;
}
.flex{ display:flex; width:100%; justify-content:center;}
a{ text-decoration:none; color:white;}

        </style>
    </body>
    <form action=# method=post>
    <div class="a">
        <div class=b> <a href=home.php class=c>Home</a><a href=menu.php class=c>Recipes</a></div>
        </div>
<body>

<?php 
$a=$_GET['id'];
$con=mysqli_connect('localhost','root','','restaurant');
$q="select * from product where pname='$a'";
$rs=mysqli_query($con,$q);
if($row=mysqli_fetch_array($rs))
{
    echo"
  
  <div class=flex>
  <div><a href='menu.php' style='margin-left:100px; margin-top:40px;'><input type=button class=button value='Back to Recipe List'></a><br>
  <div> <img src='$row[photo]' style='height:350px; margin-left:100px; margin-top:10px;  width:400px;'></div></div>";
}?>
<?php 
$a=$_GET['id'];
$con=mysqli_connect('localhost','root','','restaurant');
$q="select * from recipe where pname='$a'";
$rs=mysqli_query($con,$q);
if($row=mysqli_fetch_array($rs))
{
    echo"
  <div class=detail><h3>$row[pname]</h3>
   <p>By:The Pioneer woman</p>
  <button class=button> <a href='https://therecipecritic.com/bubble-pizza/' >Publisher Webpage</a></button>
  <button class=button1>  <a href='https://therecipecritic.com/bubble-pizza/'>Recipe URL</a></button><br><br>
          
          <h3> $row[pname]</h3>
          <h5>$row[detail]</h5><hr>


}
?>
</body>
</html>